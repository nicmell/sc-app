// Example plugin script — runs after DOM is injected into host page.
// sc-fader and sc-toggle web components are provided by the host app.
console.log("Example synth plugin loaded");
